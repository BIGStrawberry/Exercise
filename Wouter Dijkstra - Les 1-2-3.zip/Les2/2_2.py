'''
    Author: Wouter Dijkstra
'''
#Practice Exercise 2_2 (if-statement)
score = input('2_2: Geef je score: ')

if (int(score) > 15):
    print('2_2:','Gefeliciteerd! Met een score van ' + score + ' ben je geslaagd!')
else:
    print('2_2:','Balen, met een score van ' + score + ' ben je NIET geslaagd')
