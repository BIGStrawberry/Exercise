'''
    Author: Wouter Dijkstra
'''
#Practice Exercise 2_5 (for + if)
string = "Guido van Rossum heeft programmeertaal Python bedacht."
aeiou = ['a', 'e', 'i', 'o', 'u']
print('2_5:', "#######")
for s in string:
    if(s in aeiou):
        print(s)



