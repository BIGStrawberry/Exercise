'''
    Author: Wouter Dijkstra
'''
#Practice Exercise 2_4 (if-else)
print('2_4', "Done!")
