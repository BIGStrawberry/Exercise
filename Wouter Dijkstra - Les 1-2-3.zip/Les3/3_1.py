'''
    Author: Wouter Dijkstra
'''
#Practice Exercise 3_1 (functie met 3 parameters)
def som(getal_1, getal_2, getal_3):
    return getal_1 + getal_2 + getal_3

getal_1 = 5
getal_2 = 10
getal_3 = 15
som = som(getal_1, getal_2, getal_3)
print(som)
